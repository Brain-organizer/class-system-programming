#include <stdio.h>

int main(){
	printf("The sum of 1 to 500 is %d\n", (1+500)*500/2);
	return 0;
}
