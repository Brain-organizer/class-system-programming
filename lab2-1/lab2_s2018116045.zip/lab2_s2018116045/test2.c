#include <stdio.h>

int main(){
	int a;
	int b;
	a=0;
	b=10;
	int sum = a+b;

	int arr[sum+1];
	arr[sum] = 1;
	return 0;
}
